#ifndef UTILS_HPP
#define UTILS_HPP

#include "../include/evento.hpp"

void printEvento(const Evento* e);

#endif